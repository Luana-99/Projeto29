export interface Cliente {
    id: string;
    nome: string ;
    fone: string ;
    email: string ;
    senha: string;
    endereco:string;
    cidade:string;
    estado:string;
    bairro:string;
    }
