import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cliente.component.html',
  styleUrls: ['./cliente.component.css'],
})
export class Cadastro implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
